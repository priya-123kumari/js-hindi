console.log("Priya")
const accountId = 14453
let accountEmail= "prihuchaudhary10523@gmail.com"
var accountPassword="12345"
accountCity="jaipur"
let accountState;
//accountId=1224
accountEmail="priya@gmail.com"
accountPassword="12234657"
accountCity="harayana"
console.log(accountState)


console.log(accountId);
console.log(accountEmail);
console.table([accountEmail,accountPassword,accountId,accountCity,accountState]);

