"use strict";
console.log("priya")
console.log(3+3)
let name=("priya")
let isLoggedIn=false
let age=18
console.table([age,isLoggedIn,name])
console.log(typeof age);
console.log(typeof "priya");
console.log(typeof isLoggedIn );
console.log(typeof null);
console.log(typeof undefined);
